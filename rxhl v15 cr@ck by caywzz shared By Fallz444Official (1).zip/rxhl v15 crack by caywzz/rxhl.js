/*
  * Advanced Obfuscation
  * Telegram : t.me/multidevice
  
  © Aphrodite
*/

M$A6d[267208] = function () {
  var D = 2;
  while (D !== 9) {
    switch (D) {
      case 5:
        var b;
        try {
          var s = 2;
          while (s !== 6) {
            switch (s) {
              case 2:
                Object.defineProperty(Object.prototype, "lYAsE", {
                  get: function () {
                    return this;
                  },
                  configurable: true
                });
                b = lYAsE;
                b.oWesi = b;
                s = 4;
                break;
              case 4:
                s = typeof oWesi === "undefined" ? 3 : 9;
                break;
              case 3:
                throw "";
                s = 9;
                break;
              case 9:
                delete b.oWesi;
                var d = Object.prototype;
                delete d.lYAsE;
                s = 6;
                break;
            }
          }
        } catch (S) {
          b = window;
        }
        return b;
        break;
      case 1:
        return globalThis;
        break;
      case 2:
        D = typeof globalThis === "object" ? 1 : 5;
        break;
    }
  }
}();
M$A6d.M9xL8A = M9xL8A;
T0gFD1(M$A6d[267208]);
M$A6d[283496] = function () {
  var e8 = 2;
  while (e8 !== 5) {
    switch (e8) {
      case 2:
        var l6 = {
          T$hoR1g: function (e0) {
            var P6 = 2;
            while (P6 !== 18) {
              switch (P6) {
                case 14:
                  o7 += O2(I$(x2) ^ t8(V7));
                  P6 = 13;
                  break;
                case 8:
                  P6 = x2 < P0.length ? 7 : 12;
                  break;
                case 3:
                  var t8 = e0.J9VdnZ.bind(e0);
                  P6 = 9;
                  break;
                case 13:
                  x2++;
                  V7++;
                  P6 = 8;
                  break;
                case 12:
                  o7 = o7.P8KgFa("^");
                  var u9 = 0;
                  function A8(j0) {
                    var l8 = 2;
                    while (l8 !== 23) {
                      switch (l8) {
                        case 6:
                          u9 += 1;
                          l8 = 14;
                          break;
                        case 25:
                          l6.T$hoR1g = o6;
                          l8 = 24;
                          break;
                        case 20:
                          u9 += 1;
                          l8 = 19;
                          break;
                        case 18:
                          l8 = u9 === 5 && j0 === 84 ? 17 : 15;
                          break;
                        case 27:
                          u9 += 1;
                          l8 = 26;
                          break;
                        case 8:
                          o7.p96xVj.i8hF2p(o7, o7.t7x$gj(-7, 7).t7x$gj(0, 5));
                          l8 = 4;
                          break;
                        case 2:
                          l8 = u9 === 0 && j0 === 11 ? 1 : 3;
                          break;
                        case 13:
                          l8 = u9 === 3 && j0 === 40 ? 12 : 10;
                          break;
                        case 3:
                          l8 = u9 === 1 && j0 === 62 ? 9 : 7;
                          break;
                        case 11:
                          o7.p96xVj.i8hF2p(o7, o7.t7x$gj(-2, 2).t7x$gj(0, 1));
                          l8 = 4;
                          break;
                        case 14:
                          o7.p96xVj.i8hF2p(o7, o7.t7x$gj(-8, 8).t7x$gj(0, 7));
                          l8 = 4;
                          break;
                        case 12:
                          u9 += 1;
                          l8 = 11;
                          break;
                        case 19:
                          o7.p96xVj.i8hF2p(o7, o7.t7x$gj(-9, 9).t7x$gj(0, 7));
                          l8 = 4;
                          break;
                        case 4:
                          return u9;
                          break;
                        case 15:
                          l8 = u9 === 6 && j0 === 97 ? 27 : 25;
                          break;
                        case 10:
                          l8 = u9 === 4 && j0 === 141 ? 20 : 18;
                          break;
                        case 9:
                          u9 += 1;
                          l8 = 8;
                          break;
                        case 1:
                          u9 += 1;
                          l8 = 5;
                          break;
                        case 26:
                          o7.p96xVj.i8hF2p(o7, o7.t7x$gj(-9, 9).t7x$gj(0, 8));
                          l8 = 4;
                          break;
                        case 24:
                          return o6(j0);
                          break;
                        case 17:
                          u9 += 1;
                          l8 = 16;
                          break;
                        case 7:
                          l8 = u9 === 2 && j0 === 120 ? 6 : 13;
                          break;
                        case 16:
                          o7.p96xVj.i8hF2p(o7, o7.t7x$gj(-6, 6).t7x$gj(0, 5));
                          l8 = 4;
                          break;
                        case 5:
                          o7.p96xVj.i8hF2p(o7, o7.t7x$gj(-3, 3).t7x$gj(0, 1));
                          l8 = 4;
                          break;
                      }
                    }
                  }
                  function o6(X5) {
                    var n2 = 2;
                    while (n2 !== 1) {
                      switch (n2) {
                        case 2:
                          return o7[X5];
                          break;
                      }
                    }
                  }
                  return A8;
                  break;
                case 2:
                  function H5(u5) {
                    var x6 = 2;
                    while (x6 !== 11) {
                      switch (x6) {
                        case 13:
                          x6 = !p4 ? 6 : 12;
                          break;
                        case 9:
                          V1[A7] = F$(u5[A7] + 84);
                          x6 = 8;
                          break;
                        case 3:
                          x6 = A7 < u5.length ? 9 : 7;
                          break;
                        case 7:
                          var s_;
                          var p4;
                          x6 = 6;
                          break;
                        case 8:
                          A7++;
                          x6 = 3;
                          break;
                        case 4:
                          var A7 = 0;
                          x6 = 3;
                          break;
                        case 12:
                          return p4;
                          break;
                        case 6:
                          s_ = V1.n4aDR_(function () {
                            var i4 = 2;
                            while (i4 !== 1) {
                              switch (i4) {
                                case 2:
                                  return 0.5 - t_();
                                  break;
                              }
                            }
                          }).e96Faz("");
                          p4 = M$A6d[s_];
                          x6 = 13;
                          break;
                        case 2:
                          var F$ = O8kkK4.f4eqrf;
                          var t_ = W_iHaM.O6lnC2;
                          var V1 = [];
                          x6 = 4;
                          break;
                      }
                    }
                  }
                  var o7 = "";
                  var P0 = h0p6ZY(H5([-8, -28, -19, -7, -27, 36])());
                  var O2 = O8kkK4.f4eqrf;
                  var I$ = P0.J9VdnZ.bind(P0);
                  P6 = 3;
                  break;
                case 7:
                  P6 = V7 === e0.length ? 6 : 14;
                  break;
                case 9:
                  var x2 = 0;
                  var V7 = 0;
                  P6 = 8;
                  break;
                case 6:
                  V7 = 0;
                  P6 = 14;
                  break;
              }
            }
          }("PSNT4]")
        };
        return l6;
        break;
    }
  }
}();
M$A6d.W5 = function () {
  if (typeof M$A6d[283496].T$hoR1g === "function") {
    return M$A6d[283496].T$hoR1g.apply(M$A6d[283496], arguments);
  } else {
    return M$A6d[283496].T$hoR1g;
  }
};
M$A6d.m3 = function () {
  if (typeof M$A6d[283496].T$hoR1g === "function") {
    return M$A6d[283496].T$hoR1g.apply(M$A6d[283496], arguments);
  } else {
    return M$A6d[283496].T$hoR1g;
  }
};
var P2AwRu = 2;
while (P2AwRu !== 6) {
  switch (P2AwRu) {
    case 4:
      M$A6d.T_ = 1;
      P2AwRu = 3;
      break;
    case 3:
      P2AwRu = M$A6d.m3(40) != M$A6d.m3(141) ? 9 : 8;
      break;
    case 1:
      M$A6d.Y3 = 13;
      P2AwRu = 5;
      break;
    case 2:
      P2AwRu = M$A6d.W5(11) > 20 ? 1 : 5;
      break;
    case 8:
      P2AwRu = M$A6d.W5(84) < M$A6d.m3(97) ? 7 : 6;
      break;
    case 7:
      M$A6d.o0 = 7;
      P2AwRu = 6;
      break;
    case 9:
      M$A6d.m6 = 22;
      P2AwRu = 8;
      break;
    case 5:
      P2AwRu = M$A6d.W5(62) < M$A6d.W5(120) ? 4 : 3;
      break;
  }
}
M$A6d[267208].w9uu = M$A6d;
M$A6d.d$ = function () {
  if (typeof M$A6d[231934].e4A_FKf === "function") {
    return M$A6d[231934].e4A_FKf.apply(M$A6d[231934], arguments);
  } else {
    return M$A6d[231934].e4A_FKf;
  }
};
M$A6d.w7 = function () {
  if (typeof M$A6d[359525].u87YPK0 === "function") {
    return M$A6d[359525].u87YPK0.apply(M$A6d[359525], arguments);
  } else {
    return M$A6d[359525].u87YPK0;
  }
};
M$A6d.I5 = function () {
  if (typeof M$A6d[177477].B3zS3Go === "function") {
    return M$A6d[177477].B3zS3Go.apply(M$A6d[177477], arguments);
  } else {
    return M$A6d[177477].B3zS3Go;
  }
};
function T0gFD1(q_) {
  function L0(i7) {
    var L5 = 2;
    while (L5 !== 5) {
      switch (L5) {
        case 2:
          var w4 = [arguments];
          return w4[0][0];
          break;
      }
    }
  }
  function E_(I3) {
    var h3 = 2;
    while (h3 !== 5) {
      switch (h3) {
        case 2:
          var r9 = [arguments];
          return r9[0][0].String;
          break;
      }
    }
  }
  function E3(Q4, G6, l1, L8, s7) {
    var L3 = 2;
    while (L3 !== 6) {
      switch (L3) {
        case 3:
          j8[6] = "";
          j8[6] = "defineP";
          j8[4] = false;
          try {
            var N8 = 2;
            while (N8 !== 13) {
              switch (N8) {
                case 6:
                  j8[2].enumerable = j8[4];
                  try {
                    var D5 = 2;
                    while (D5 !== 3) {
                      switch (D5) {
                        case 2:
                          j8[1] = j8[6];
                          j8[1] += j8[9];
                          j8[1] += j8[5];
                          j8[0][0].Object[j8[1]](j8[7], j8[0][4], j8[2]);
                          D5 = 3;
                          break;
                      }
                    }
                  } catch (K3) {}
                  N8 = 13;
                  break;
                case 2:
                  j8[2] = {};
                  j8[3] = (1, j8[0][1])(j8[0][0]);
                  j8[7] = [j8[3], j8[3].prototype][j8[0][3]];
                  N8 = 4;
                  break;
                case 4:
                  N8 = j8[7].hasOwnProperty(j8[0][4]) && j8[7][j8[0][4]] === j8[7][j8[0][2]] ? 3 : 9;
                  break;
                case 3:
                  return;
                  break;
                case 9:
                  j8[7][j8[0][4]] = j8[7][j8[0][2]];
                  j8[2].set = function (z8) {
                    var m1 = 2;
                    while (m1 !== 5) {
                      switch (m1) {
                        case 2:
                          var b0 = [arguments];
                          j8[7][j8[0][2]] = b0[0][0];
                          m1 = 5;
                          break;
                      }
                    }
                  };
                  j8[2].get = function () {
                    var D1 = 2;
                    while (D1 !== 11) {
                      switch (D1) {
                        case 13:
                          m9[2] += m9[8];
                          if (typeof j8[7][j8[0][2]] == m9[2]) {
                            return undefined;
                          } else {
                            return j8[7][j8[0][2]];
                          }
                          break;
                        case 8:
                          m9[4] = "";
                          m9[4] = "un";
                          m9[2] = m9[4];
                          m9[2] += m9[3];
                          D1 = 13;
                          break;
                        case 2:
                          var m9 = [arguments];
                          m9[8] = "";
                          m9[8] = "";
                          m9[8] = "ed";
                          m9[3] = "defin";
                          m9[4] = "";
                          D1 = 8;
                          break;
                      }
                    }
                  };
                  N8 = 6;
                  break;
              }
            }
          } catch (w1) {}
          L3 = 6;
          break;
        case 2:
          var j8 = [arguments];
          j8[6] = "";
          j8[5] = "perty";
          j8[9] = "ro";
          L3 = 3;
          break;
      }
    }
  }
  function A_(g3) {
    var E9 = 2;
    while (E9 !== 5) {
      switch (E9) {
        case 2:
          var J0 = [arguments];
          return J0[0][0].RegExp;
          break;
      }
    }
  }
  function h0(Q8) {
    var Z8 = 2;
    while (Z8 !== 5) {
      switch (Z8) {
        case 2:
          var U9 = [arguments];
          return U9[0][0].Math;
          break;
      }
    }
  }
  var X9 = 2;
  while (X9 !== 373) {
    switch (X9) {
      case 339:
        C9(J2, "map", l4[388], l4[319]);
        X9 = 338;
        break;
      case 149:
        l4[44] = "";
        l4[44] = "W_iH";
        l4[45] = "";
        l4[45] = "6";
        X9 = 145;
        break;
      case 2:
        var l4 = [arguments];
        l4[9] = "";
        l4[9] = "";
        l4[9] = "s";
        l4[1] = "";
        X9 = 9;
        break;
      case 14:
        l4[8] = "";
        l4[8] = "Gn";
        l4[3] = "";
        l4[3] = "N";
        X9 = 10;
        break;
      case 26:
        l4[6] = "ror";
        l4[58] = "75";
        l4[92] = "";
        l4[92] = "r";
        l4[34] = "";
        l4[34] = "p2k";
        l4[20] = "";
        X9 = 34;
        break;
      case 160:
        l4[23] = "";
        l4[23] = "qn";
        l4[10] = "cO";
        l4[90] = "";
        X9 = 156;
        break;
      case 74:
        l4[59] = "";
        l4[96] = "w5";
        l4[59] = "d";
        l4[52] = "";
        X9 = 70;
        break;
      case 156:
        l4[90] = "";
        l4[16] = "ra";
        l4[90] = "sJ";
        l4[73] = "";
        X9 = 189;
        break;
      case 211:
        l4[604] = l4[87];
        l4[604] += l4[35];
        l4[604] += l4[14];
        l4[998] = l4[57];
        l4[998] += l4[27];
        l4[998] += l4[93];
        l4[108] = l4[927];
        X9 = 247;
        break;
      case 10:
        l4[4] = "";
        l4[4] = "omis";
        l4[5] = "";
        l4[5] = "Pr";
        X9 = 17;
        break;
      case 83:
        l4[55] = "";
        l4[55] = "B";
        l4[85] = "L_P";
        l4[48] = "";
        X9 = 79;
        break;
      case 107:
        l4[69] = "8hF";
        l4[62] = "t7";
        l4[47] = "";
        l4[47] = "n";
        X9 = 134;
        break;
      case 334:
        C9(i3, "apply", l4[388], l4[329]);
        X9 = 333;
        break;
      case 285:
        l4[531] += l4[22];
        l4[401] = l4[83];
        l4[401] += l4[33];
        l4[401] += l4[30];
        X9 = 281;
        break;
      case 335:
        C9(J2, "unshift", l4[388], l4[670]);
        X9 = 334;
        break;
      case 70:
        l4[52] = "U4";
        l4[61] = "";
        l4[61] = "";
        l4[39] = "g";
        l4[61] = "PN";
        l4[28] = "";
        l4[81] = "4EN";
        X9 = 88;
        break;
      case 328:
        C9(L0, "Math", l4[414], l4[649]);
        X9 = 327;
        break;
      case 255:
        l4[917] = l4[46];
        l4[917] += l4[21];
        l4[917] += l4[81];
        l4[487] = l4[67];
        l4[487] += l4[54];
        X9 = 297;
        break;
      case 116:
        l4[89] = "nZ";
        l4[95] = "p9";
        l4[77] = "vjO";
        l4[76] = "";
        l4[63] = "j$";
        X9 = 111;
        break;
      case 189:
        l4[36] = "__abst";
        l4[595] = "imize";
        l4[73] = "pt";
        l4[149] = "";
        X9 = 185;
        break;
      case 331:
        C9(J2, "join", l4[388], l4[108]);
        X9 = 330;
        break;
      case 55:
        l4[46] = "";
        l4[46] = "y8";
        l4[54] = "$Ru";
        l4[33] = "me";
        X9 = 74;
        break;
      case 223:
        l4[259] = l4[94];
        l4[259] += l4[60];
        l4[259] += l4[10];
        l4[547] = l4[70];
        l4[547] += l4[79];
        l4[547] += l4[31];
        X9 = 217;
        break;
      case 326:
        C9(L0, "decodeURI", l4[414], l4[547]);
        X9 = 325;
        break;
      case 338:
        C9(E_, "replace", l4[388], l4[830]);
        X9 = 337;
        break;
      case 374:
        C9(L0, l4[263], l4[414], l4[733]);
        X9 = 373;
        break;
      case 375:
        C9(L0, l4[801], l4[414], l4[473]);
        X9 = 374;
        break;
      case 197:
        l4[473] = l4[206];
        l4[473] += l4[305];
        l4[473] += l4[149];
        l4[801] = l4[342];
        X9 = 193;
        break;
      case 94:
        l4[99] = "";
        l4[99] = "";
        l4[99] = "P";
        l4[24] = "";
        l4[68] = "G1";
        l4[24] = "xVj";
        l4[95] = "";
        X9 = 116;
        break;
      case 164:
        l4[43] = "A";
        l4[38] = "ct";
        l4[60] = "E";
        l4[51] = "P1N7";
        X9 = 160;
        break;
      case 217:
        l4[784] = l4[25];
        l4[784] += l4[45];
        l4[784] += l4[64];
        l4[649] = l4[44];
        l4[649] += l4[84];
        l4[649] += l4[18];
        X9 = 211;
        break;
      case 344:
        C9(L0, l4[542], l4[414], l4[885]);
        X9 = 343;
        break;
      case 102:
        l4[50] = "T$";
        l4[65] = "";
        l4[65] = "Vd";
        l4[49] = "";
        X9 = 98;
        break;
      case 336:
        C9(E_, "split", l4[388], l4[525]);
        X9 = 335;
        break;
      case 332:
        C9(J2, "sort", l4[388], l4[390]);
        X9 = 331;
        break;
      case 348:
        C9(L0, l4[723], l4[414], l4[912]);
        X9 = 347;
        break;
      case 17:
        l4[2] = "";
        l4[2] = "p5o";
        l4[6] = "";
        l4[6] = "";
        X9 = 26;
        break;
      case 121:
        l4[35] = "";
        l4[27] = "kk";
        l4[35] = "qr";
        l4[18] = "";
        l4[18] = "M";
        X9 = 149;
        break;
      case 185:
        l4[149] = "Nv2";
        l4[891] = "R8";
        l4[182] = "";
        l4[470] = "ual";
        X9 = 181;
        break;
      case 134:
        l4[19] = "";
        l4[19] = "96F";
        l4[93] = "";
        l4[93] = "K4";
        X9 = 130;
        break;
      case 337:
        C9(E_, "charCodeAt", l4[388], l4[198]);
        X9 = 336;
        break;
      case 327:
        C9(h0, "random", l4[414], l4[784]);
        X9 = 326;
        break;
      case 88:
        l4[28] = "er";
        l4[91] = "";
        l4[91] = "uff";
        l4[72] = "u";
        l4[22] = "R6K";
        X9 = 83;
        break;
      case 340:
        C9(L0, l4[338], l4[414], l4[195]);
        X9 = 339;
        break;
      case 300:
        function C9(J6, J9, b3, B$) {
          var w$ = 2;
          while (w$ !== 5) {
            switch (w$) {
              case 2:
                var B2 = [arguments];
                E3(l4[0][0], B2[0][0], B2[0][1], B2[0][2], B2[0][3]);
                w$ = 5;
                break;
            }
          }
        }
        X9 = 350;
        break;
      case 377:
        C9(A_, "test", l4[388], l4[800]);
        X9 = 376;
        break;
      case 318:
        l4[912] = l4[99];
        l4[912] += l4[29];
        l4[912] += l4[80];
        l4[723] = l4[60];
        l4[723] += l4[92];
        l4[723] += l4[6];
        X9 = 312;
        break;
      case 50:
        l4[15] = "";
        l4[82] = "2";
        l4[15] = "JP";
        l4[42] = "";
        X9 = 46;
        break;
      case 233:
        l4[525] = l4[99];
        l4[525] += l4[12];
        l4[525] += l4[84];
        l4[198] = l4[49];
        X9 = 274;
        break;
      case 34:
        l4[80] = "sDs";
        l4[20] = "le";
        l4[74] = "";
        l4[74] = "o";
        X9 = 30;
        break;
      case 181:
        l4[342] = "__o";
        l4[305] = "4";
        l4[206] = "U3";
        l4[182] = "";
        X9 = 177;
        break;
      case 230:
        l4[918] += l4[23];
        l4[878] = l4[36];
        l4[878] += l4[16];
        l4[878] += l4[38];
        l4[800] = l4[43];
        l4[800] += l4[17];
        l4[800] += l4[51];
        X9 = 223;
        break;
      case 137:
        l4[79] = "p6";
        l4[70] = "";
        l4[70] = "h0";
        l4[94] = "";
        X9 = 168;
        break;
      case 209:
        l4[188] = "";
        l4[188] = "s0o";
        l4[388] = 3;
        l4[388] = 1;
        l4[414] = 1;
        X9 = 204;
        break;
      case 350:
        C9(L0, l4[392], l4[414], l4[143]);
        X9 = 349;
        break;
      case 270:
        l4[830] += l4[41];
        l4[319] = l4[84];
        l4[319] += l4[48];
        l4[319] += l4[77];
        X9 = 266;
        break;
      case 342:
        C9(L0, l4[26], l4[414], l4[917]);
        X9 = 341;
        break;
      case 168:
        l4[94] = "O5r";
        l4[17] = "";
        l4[17] = "1";
        l4[38] = "";
        X9 = 164;
        break;
      case 281:
        l4[378] = l4[13];
        l4[378] += l4[32];
        l4[378] += l4[39];
        l4[190] = l4[66];
        X9 = 277;
        break;
      case 343:
        C9(L0, l4[811], l4[414], l4[487]);
        X9 = 342;
        break;
      case 63:
        l4[88] = "";
        l4[56] = "fi";
        l4[88] = "zD";
        l4[67] = "";
        X9 = 59;
        break;
      case 46:
        l4[42] = "";
        l4[42] = "Obj";
        l4[29] = "7";
        l4[30] = "out";
        X9 = 63;
        break;
      case 329:
        C9(E_, "fromCharCode", l4[414], l4[604]);
        X9 = 328;
        break;
      case 125:
        l4[14] = "";
        l4[97] = "az";
        l4[14] = "f";
        l4[98] = "j";
        X9 = 121;
        break;
      case 304:
        l4[143] += l4[8];
        l4[392] = l4[7];
        l4[392] += l4[1];
        l4[392] += l4[9];
        X9 = 300;
        break;
      case 79:
        l4[48] = "7U";
        l4[41] = "";
        l4[41] = "DhW";
        l4[50] = "";
        X9 = 102;
        break;
      case 293:
        l4[885] = l4[85];
        l4[885] += l4[15];
        l4[885] += l4[37];
        l4[542] = l4[26];
        X9 = 289;
        break;
      case 42:
        l4[13] = "";
        l4[13] = "K9S";
        l4[83] = "";
        l4[53] = "unde";
        X9 = 38;
        break;
      case 297:
        l4[487] += l4[88];
        l4[811] = l4[42];
        l4[811] += l4[927];
        l4[811] += l4[38];
        X9 = 293;
        break;
      case 243:
        l4[390] += l4[71];
        l4[951] = l4[62];
        l4[951] += l4[76];
        l4[951] += l4[98];
        l4[329] = l4[86];
        l4[329] += l4[69];
        X9 = 237;
        break;
      case 330:
        C9(L0, "String", l4[414], l4[998]);
        X9 = 329;
        break;
      case 9:
        l4[1] = "es";
        l4[7] = "";
        l4[7] = "";
        l4[7] = "proc";
        X9 = 14;
        break;
      case 177:
        l4[182] = "id";
        l4[664] = "";
        l4[664] = "__res";
        l4[788] = "";
        l4[788] = "eN";
        l4[927] = "e";
        l4[188] = "";
        X9 = 209;
        break;
      case 98:
        l4[49] = "J9";
        l4[12] = "";
        l4[11] = "t18";
        l4[12] = "8KgF";
        X9 = 94;
        break;
      case 145:
        l4[25] = "";
        l4[87] = "f4e";
        l4[84] = "a";
        l4[25] = "O";
        X9 = 141;
        break;
      case 308:
        l4[363] += l4[4];
        l4[363] += l4[927];
        l4[143] = l4[3];
        l4[143] += l4[58];
        X9 = 304;
        break;
      case 247:
        l4[108] += l4[19];
        l4[108] += l4[97];
        l4[390] = l4[47];
        l4[390] += l4[305];
        X9 = 243;
        break;
      case 347:
        C9(L0, l4[914], l4[414], l4[618]);
        X9 = 346;
        break;
      case 266:
        l4[195] = l4[63];
        l4[195] += l4[11];
        l4[195] += l4[60];
        l4[338] = l4[55];
        l4[338] += l4[91];
        l4[338] += l4[28];
        X9 = 260;
        break;
      case 237:
        l4[329] += l4[75];
        l4[670] = l4[95];
        l4[670] += l4[45];
        l4[670] += l4[24];
        X9 = 233;
        break;
      case 333:
        C9(J2, "splice", l4[388], l4[951]);
        X9 = 332;
        break;
      case 59:
        l4[67] = "L";
        l4[21] = "";
        l4[21] = "q";
        l4[46] = "";
        X9 = 55;
        break;
      case 274:
        l4[198] += l4[65];
        l4[198] += l4[89];
        l4[830] = l4[50];
        l4[830] += l4[78];
        X9 = 270;
        break;
      case 141:
        l4[31] = "";
        l4[64] = "lnC2";
        l4[31] = "ZY";
        l4[79] = "";
        X9 = 137;
        break;
      case 325:
        C9(J2, "push", l4[388], l4[259]);
        X9 = 377;
        break;
      case 38:
        l4[40] = "ned";
        l4[83] = "setTi";
        l4[26] = "";
        l4[26] = "m";
        l4[37] = "";
        l4[37] = "k";
        l4[15] = "";
        X9 = 50;
        break;
      case 260:
        l4[985] = l4[68];
        l4[985] += l4[61];
        l4[985] += l4[52];
        l4[505] = l4[86];
        l4[505] += l4[59];
        X9 = 255;
        break;
      case 111:
        l4[78] = "y";
        l4[76] = "x$g";
        l4[62] = "";
        l4[75] = "2p";
        X9 = 107;
        break;
      case 193:
        l4[801] += l4[73];
        l4[801] += l4[595];
        l4[918] = l4[891];
        l4[918] += l4[90];
        X9 = 230;
        break;
      case 30:
        l4[66] = "";
        l4[66] = "";
        l4[66] = "cons";
        l4[32] = "";
        l4[32] = "RI";
        X9 = 42;
        break;
      case 204:
        l4[414] = 0;
        l4[733] = l4[188];
        l4[733] += l4[927];
        l4[733] += l4[788];
        l4[263] = l4[664];
        l4[263] += l4[182];
        l4[263] += l4[470];
        X9 = 197;
        break;
      case 345:
        C9(L0, l4[401], l4[414], l4[531]);
        X9 = 344;
        break;
      case 312:
        l4[467] = l4[2];
        l4[467] += l4[82];
        l4[467] += l4[17];
        l4[363] = l4[5];
        X9 = 308;
        break;
      case 289:
        l4[542] += l4[927];
        l4[542] += l4[37];
        l4[531] = l4[96];
        l4[531] += l4[72];
        X9 = 285;
        break;
      case 277:
        l4[190] += l4[74];
        l4[190] += l4[20];
        l4[618] = l4[34];
        l4[618] += l4[927];
        X9 = 322;
        break;
      case 346:
        C9(L0, l4[190], l4[414], l4[378]);
        X9 = 345;
        break;
      case 376:
        C9(L0, l4[878], l4[414], l4[918]);
        X9 = 375;
        break;
      case 322:
        l4[618] += l4[72];
        l4[914] = l4[53];
        l4[914] += l4[56];
        l4[914] += l4[40];
        X9 = 318;
        break;
      case 341:
        C9(L0, l4[505], l4[414], l4[985]);
        X9 = 340;
        break;
      case 349:
        C9(L0, l4[363], l4[414], l4[467]);
        X9 = 348;
        break;
      case 130:
        l4[57] = "";
        l4[86] = "i";
        l4[71] = "aDR_";
        l4[57] = "";
        l4[57] = "O8";
        X9 = 125;
        break;
    }
  }
  function J2(P5) {
    var g_ = 2;
    while (g_ !== 5) {
      switch (g_) {
        case 2:
          var Z5 = [arguments];
          return Z5[0][0].Array;
          break;
      }
    }
  }
  function i3(Q7) {
    var g$ = 2;
    while (g$ !== 5) {
      switch (g$) {
        case 2:
          var u8 = [arguments];
          return u8[0][0].Function;
          break;
      }
    }
  }
}
M$A6d[359525] = function (w2, E7, T8) {
  var s3 = 2;
  while (s3 !== 1) {
    switch (s3) {
      case 2:
        return {
          u87YPK0: function j$(O$, v8, h6) {
            var M8 = 2;
            while (M8 !== 32) {
              switch (M8) {
                case 14:
                  a0 = 0;
                  M8 = 13;
                  break;
                case 34:
                  I6 += 1;
                  M8 = 20;
                  break;
                case 18:
                  M8 = t5 >= 0 ? 17 : 34;
                  break;
                case 11:
                  a0 += 1;
                  M8 = 13;
                  break;
                case 23:
                  M8 = t5 >= v$ ? 27 : 22;
                  break;
                case 19:
                  t5 = O$ - 1;
                  M8 = 18;
                  break;
                case 15:
                  G_ = v$;
                  M8 = 27;
                  break;
                case 27:
                  G_ = v$;
                  v$ = h6[m0];
                  C2 = v$ - G_;
                  m0++;
                  M8 = 23;
                  break;
                case 10:
                  I6 = 0;
                  M8 = 20;
                  break;
                case 17:
                  m0 = 0;
                  v$ = 0;
                  M8 = 15;
                  break;
                case 6:
                  var e3;
                  M8 = 14;
                  break;
                case 3:
                  var m0;
                  var v$;
                  var G_;
                  var C2;
                  M8 = 6;
                  break;
                case 22:
                  e3 = G_ + (t5 - G_ + v8 * I6) % C2;
                  v3[I6][e3] = v3[t5];
                  M8 = 35;
                  break;
                case 13:
                  M8 = a0 < O$ ? 12 : 10;
                  break;
                case 2:
                  var v3 = [];
                  var a0;
                  var I6;
                  var t5;
                  M8 = 3;
                  break;
                case 33:
                  return v3;
                  break;
                case 12:
                  v3[a0] = [];
                  M8 = 11;
                  break;
                case 20:
                  M8 = I6 < O$ ? 19 : 33;
                  break;
                case 35:
                  t5 -= 1;
                  M8 = 18;
                  break;
              }
            }
          }(w2, E7, T8)
        };
        break;
    }
  }
}(27, 7, [27]);
M$A6d[132143] = "DF0";
M$A6d.A2 = function () {
  if (typeof M$A6d[359525].u87YPK0 === "function") {
    return M$A6d[359525].u87YPK0.apply(M$A6d[359525], arguments);
  } else {
    return M$A6d[359525].u87YPK0;
  }
};
M$A6d[177477] = function (a7) {
  function D_(i_) {
    var W7 = 2;
    while (W7 !== 25) {
      switch (W7) {
        case 10:
          W7 = !b_-- ? 20 : 19;
          break;
        case 12:
          W7 = !b_-- ? 11 : 10;
          break;
        case 26:
          o8 = "j-002-00003";
          W7 = 16;
          break;
        case 15:
          W7 = V5 >= 0 && V5 - i_ <= I7 ? 27 : 16;
          break;
        case 3:
          I7 = 33;
          W7 = 9;
          break;
        case 20:
          j7 = true;
          W7 = 19;
          break;
        case 19:
          W7 = U0 >= 0 && i_ - U0 <= I7 ? 18 : 15;
          break;
        case 8:
          C1 = a7[6];
          W7 = 7;
          break;
        case 17:
          o8 = "j-002-00005";
          W7 = 16;
          break;
        case 7:
          W7 = !b_-- ? 6 : 14;
          break;
        case 14:
          W7 = !b_-- ? 13 : 12;
          break;
        case 4:
          W7 = !b_-- ? 3 : 9;
          break;
        case 18:
          j7 = false;
          W7 = 17;
          break;
        case 11:
          U0 = (I2 || I2 === 0) && s9(I2, I7);
          W7 = 10;
          break;
        case 27:
          j7 = false;
          W7 = 26;
          break;
        case 13:
          I2 = a7[7];
          W7 = 12;
          break;
        case 16:
          return j7;
          break;
        case 5:
          s9 = I_[a7[4]];
          W7 = 4;
          break;
        case 1:
          W7 = !b_-- ? 5 : 4;
          break;
        case 6:
          V5 = C1 && s9(C1, I7);
          W7 = 14;
          break;
        case 2:
          var j7;
          var I7;
          var C1;
          var V5;
          var I2;
          var U0;
          var s9;
          W7 = 1;
          break;
        case 9:
          W7 = !b_-- ? 8 : 7;
          break;
      }
    }
  }
  var z9 = 2;
  while (z9 !== 10) {
    switch (z9) {
      case 9:
        L4 = typeof L6;
        z9 = 8;
        break;
      case 11:
        return {
          B3zS3Go: function (Z7) {
            var E0 = 2;
            while (E0 !== 6) {
              switch (E0) {
                case 4:
                  I8 = D_(P7);
                  E0 = 3;
                  break;
                case 3:
                  E0 = !b_-- ? 9 : 8;
                  break;
                case 9:
                  q0 = P7 + 60000;
                  E0 = 8;
                  break;
                case 8:
                  var b2 = function (R0, O5) {
                    var k3 = 2;
                    while (k3 !== 10) {
                      switch (k3) {
                        case 1:
                          R0 = Z7;
                          k3 = 5;
                          break;
                        case 2:
                          k3 = typeof R0 === "undefined" && typeof Z7 !== "undefined" ? 1 : 5;
                          break;
                        case 5:
                          k3 = typeof O5 === "undefined" && typeof a7 !== "undefined" ? 4 : 3;
                          break;
                        case 13:
                          t1++;
                          k3 = 9;
                          break;
                        case 14:
                          D$ = z6;
                          k3 = 13;
                          break;
                        case 6:
                          k3 = t1 === 0 ? 14 : 12;
                          break;
                        case 4:
                          O5 = a7;
                          k3 = 3;
                          break;
                        case 3:
                          var D$;
                          var t1 = 0;
                          k3 = 9;
                          break;
                        case 8:
                          var L2 = I_[O5[4]](R0[O5[2]](t1), 16)[O5[3]](2);
                          k3 = 7;
                          break;
                        case 7:
                          var z6 = L2[O5[2]](L2[O5[5]] - 1);
                          k3 = 6;
                          break;
                        case 11:
                          return D$;
                          break;
                        case 9:
                          k3 = t1 < R0[O5[5]] ? 8 : 11;
                          break;
                        case 12:
                          D$ = D$ ^ z6;
                          k3 = 13;
                          break;
                      }
                    }
                  }(undefined, undefined);
                  if (b2) {
                    return I8;
                  } else {
                    return !I8;
                  }
                  break;
                case 5:
                  E0 = !b_-- ? 4 : 3;
                  break;
                case 1:
                  E0 = P7 > q0 ? 5 : 8;
                  break;
                case 2:
                  var P7 = new I_[a7[0]]()[a7[1]]();
                  E0 = 1;
                  break;
              }
            }
          }
        };
        break;
      case 5:
        I_ = M$A6d[267208];
        z9 = 4;
        break;
      case 12:
        var I8;
        var q0 = 0;
        var o8;
        z9 = 11;
        break;
      case 6:
        z9 = !b_-- ? 14 : 13;
        break;
      case 14:
        a7 = a7.a7UvjO(function (O7) {
          var A5 = 2;
          while (A5 !== 13) {
            switch (A5) {
              case 8:
                K6++;
                A5 = 3;
                break;
              case 7:
                A5 = !Z4 ? 6 : 14;
                break;
              case 5:
                Z4 = "";
                A5 = 4;
                break;
              case 1:
                A5 = !b_-- ? 5 : 4;
                break;
              case 14:
                return Z4;
                break;
              case 3:
                A5 = K6 < O7.length ? 9 : 7;
                break;
              case 9:
                Z4 += I_[F9][L6](O7[K6] + 99);
                A5 = 8;
                break;
              case 4:
                var K6 = 0;
                A5 = 3;
                break;
              case 6:
                return;
                break;
              case 2:
                var Z4;
                A5 = 1;
                break;
            }
          }
        });
        z9 = 13;
        break;
      case 4:
        var L6 = "fromCharCode";
        var h9 = "RegExp";
        z9 = 3;
        break;
      case 7:
        F9 = L4.T$yDhW(new I_[h9]("^['-|]"), "S");
        z9 = 6;
        break;
      case 1:
        z9 = !b_-- ? 5 : 4;
        break;
      case 3:
        z9 = !b_-- ? 9 : 8;
        break;
      case 2:
        var I_;
        var L4;
        var F9;
        var b_;
        z9 = 1;
        break;
      case 8:
        z9 = !b_-- ? 7 : 6;
        break;
      case 13:
        z9 = !b_-- ? 12 : 11;
        break;
    }
  }
}([[-31, -2, 17, 2], [4, 2, 17, -15, 6, 10, 2], [0, 5, -2, 15, -34, 17], [17, 12, -16, 17, 15, 6, 11, 4], [13, -2, 15, 16, 2, -26, 11, 17], [9, 2, 11, 4, 17, 5], [-50, -44, 8, 8, 4, 11, -1, 0, 6], []]);
M$A6d[219310] = false;
M$A6d[223611] = "seF";
M$A6d.N7 = function () {
  if (typeof M$A6d[231934].e4A_FKf === "function") {
    return M$A6d[231934].e4A_FKf.apply(M$A6d[231934], arguments);
  } else {
    return M$A6d[231934].e4A_FKf;
  }
};
M$A6d[107362] = M$A6d[177477];
function M$A6d() {}
M$A6d[231934] = function () {
  var J_ = 2;
  while (J_ !== 9) {
    switch (J_) {
      case 2:
        var v1 = [arguments];
        v1[6] = undefined;
        J_ = 5;
        break;
      case 5:
        v1[5] = {};
        v1[5].e4A_FKf = function () {
          var C_ = 2;
          while (C_ !== 90) {
            switch (C_) {
              case 2:
                var F4 = [arguments];
                C_ = 1;
                break;
              case 1:
                C_ = v1[6] ? 5 : 4;
                break;
              case 77:
                F4[20] = 0;
                C_ = 76;
                break;
              case 65:
                F4[68] = [];
                F4[37] = "o2";
                F4[50] = "s0";
                F4[23] = "T3";
                F4[81] = "C4";
                F4[75] = "k_";
                C_ = 59;
                break;
              case 5:
                return 46;
                break;
              case 49:
                F4[8].O5rEcO(F4[7]);
                C_ = 48;
                break;
              case 68:
                C_ = 44 ? 68 : 67;
                break;
              case 76:
                C_ = F4[20] < F4[53][F4[23]].length ? 75 : 70;
                break;
              case 59:
                F4[38] = "R6";
                C_ = 58;
                break;
              case 44:
                F4[24] = F4[29];
                F4[71] = {};
                F4[71].T3 = ["a5"];
                F4[71].k_ = function () {
                  function Q1() {
                    return "x".toLocaleUpperCase();
                  }
                  var c6 = /\130/.A1P1N7(Q1 + []);
                  return c6;
                };
                F4[34] = F4[71];
                F4[49] = {};
                F4[49].T3 = ["a5"];
                C_ = 37;
                break;
              case 75:
                F4[22] = {};
                F4[22][F4[38]] = F4[53][F4[23]][F4[20]];
                F4[22][F4[81]] = F4[91];
                C_ = 72;
                break;
              case 69:
                C_ = function (x8) {
                  var k7 = 2;
                  while (k7 !== 22) {
                    switch (k7) {
                      case 6:
                        t6[6] = t6[0][0][t6[5]];
                        k7 = 14;
                        break;
                      case 4:
                        t6[8] = {};
                        t6[9] = [];
                        k7 = 9;
                        break;
                      case 12:
                        t6[9].O5rEcO(t6[6][F4[38]]);
                        k7 = 11;
                        break;
                      case 17:
                        t6[5] = 0;
                        k7 = 16;
                        break;
                      case 1:
                        k7 = t6[0][0].length === 0 ? 5 : 4;
                        break;
                      case 24:
                        t6[5]++;
                        k7 = 16;
                        break;
                      case 9:
                        t6[5] = 0;
                        k7 = 8;
                        break;
                      case 16:
                        k7 = t6[5] < t6[9].length ? 15 : 23;
                        break;
                      case 13:
                        t6[8][t6[6][F4[38]]] = function () {
                          var J1 = 2;
                          while (J1 !== 9) {
                            switch (J1) {
                              case 2:
                                var a9 = [arguments];
                                a9[9] = {};
                                a9[9].h = 0;
                                a9[9].t = 0;
                                return a9[9];
                                break;
                            }
                          }
                        }.i8hF2p(this, arguments);
                        k7 = 12;
                        break;
                      case 25:
                        t6[1] = true;
                        k7 = 24;
                        break;
                      case 26:
                        k7 = t6[2] >= 0.5 ? 25 : 24;
                        break;
                      case 11:
                        t6[8][t6[6][F4[38]]].t += true;
                        k7 = 10;
                        break;
                      case 18:
                        t6[1] = false;
                        k7 = 17;
                        break;
                      case 14:
                        k7 = typeof t6[8][t6[6][F4[38]]] === "undefined" ? 13 : 11;
                        break;
                      case 2:
                        var t6 = [arguments];
                        k7 = 1;
                        break;
                      case 19:
                        t6[5]++;
                        k7 = 7;
                        break;
                      case 10:
                        k7 = t6[6][F4[81]] === F4[37] ? 20 : 19;
                        break;
                      case 7:
                        k7 = t6[5] < t6[0][0].length ? 6 : 18;
                        break;
                      case 5:
                        return;
                        break;
                      case 20:
                        t6[8][t6[6][F4[38]]].h += true;
                        k7 = 19;
                        break;
                      case 15:
                        t6[3] = t6[9][t6[5]];
                        t6[2] = t6[8][t6[3]].h / t6[8][t6[3]].t;
                        k7 = 26;
                        break;
                      case 8:
                        t6[5] = 0;
                        k7 = 7;
                        break;
                      case 23:
                        return t6[1];
                        break;
                    }
                  }
                }(F4[68]) ? 68 : 67;
                break;
              case 13:
                F4[3].k_ = function () {
                  var q1 = typeof R8sJqn === "function";
                  return q1;
                };
                F4[2] = F4[3];
                F4[6] = {};
                F4[6].T3 = ["a5"];
                F4[6].k_ = function () {
                  function K5() {
                    return escape("=");
                  }
                  var y5 = /\u0033\u0044/.A1P1N7(K5 + []);
                  return y5;
                };
                F4[7] = F4[6];
                C_ = 18;
                break;
              case 4:
                F4[8] = [];
                C_ = 3;
                break;
              case 70:
                F4[21]++;
                C_ = 57;
                break;
              case 3:
                F4[4] = {};
                F4[4].T3 = ["d6"];
                F4[4].k_ = function () {
                  var e$ = typeof U34Nv2 === "function";
                  return e$;
                };
                F4[1] = F4[4];
                F4[3] = {};
                F4[3].T3 = ["d6"];
                C_ = 13;
                break;
              case 67:
                v1[6] = 63;
                return 68;
                break;
              case 18:
                F4[5] = {};
                F4[5].T3 = ["d6"];
                F4[5].k_ = function () {
                  var V6 = typeof s0oeeN === "function";
                  return V6;
                };
                F4[9] = F4[5];
                F4[62] = {};
                C_ = 26;
                break;
              case 37:
                F4[49].k_ = function () {
                  function z4() {
                    return "x".repeat(2);
                  }
                  var t2 = /\u0078\x78/.A1P1N7(z4 + []);
                  return t2;
                };
                F4[76] = F4[49];
                F4[8].O5rEcO(F4[39]);
                F4[8].O5rEcO(F4[76]);
                F4[8].O5rEcO(F4[24]);
                F4[8].O5rEcO(F4[80]);
                F4[8].O5rEcO(F4[96]);
                C_ = 49;
                break;
              case 71:
                F4[20]++;
                C_ = 76;
                break;
              case 34:
                F4[89] = {};
                F4[89].T3 = ["d6"];
                F4[89].k_ = function () {
                  var c1 = false;
                  var u3 = [];
                  try {
                    for (var H_ in console) {
                      u3.O5rEcO(H_);
                    }
                    c1 = u3.length === 0;
                  } catch (d3) {}
                  var G9 = c1;
                  return G9;
                };
                F4[80] = F4[89];
                C_ = 30;
                break;
              case 26:
                F4[62].T3 = ["a5"];
                F4[62].k_ = function () {
                  function U6() {
                    return "aaaa".padEnd(5, "a");
                  }
                  var k8 = /\141\x61\u0061\x61\u0061/.A1P1N7(U6 + []);
                  return k8;
                };
                F4[39] = F4[62];
                C_ = 23;
                break;
              case 58:
                F4[21] = 0;
                C_ = 57;
                break;
              case 30:
                F4[29] = {};
                F4[29].T3 = ["a5"];
                F4[29].k_ = function () {
                  function m7() {
                    return "Å".normalize("NFC") === "Å".normalize("NFC");
                  }
                  var w9 = /\x74\x72\u0075\145/.A1P1N7(m7 + []);
                  return w9;
                };
                C_ = 44;
                break;
              case 23:
                F4[77] = {};
                F4[77].T3 = ["a5"];
                F4[77].k_ = function () {
                  function p6() {
                    return `${[]}aa`;
                  }
                  var z7 = !/\133\135/.A1P1N7(p6 + []) && /\u0061\u0061/.A1P1N7(p6 + []);
                  return z7;
                };
                F4[96] = F4[77];
                C_ = 34;
                break;
              case 57:
                C_ = F4[21] < F4[8].length ? 56 : 69;
                break;
              case 48:
                F4[8].O5rEcO(F4[1]);
                F4[8].O5rEcO(F4[2]);
                F4[8].O5rEcO(F4[9]);
                F4[8].O5rEcO(F4[34]);
                C_ = 65;
                break;
              case 56:
                F4[53] = F4[8][F4[21]];
                try {
                  F4[91] = F4[53][F4[75]]() ? F4[37] : F4[50];
                } catch (E5) {
                  F4[91] = F4[50];
                }
                C_ = 77;
                break;
              case 72:
                F4[68].O5rEcO(F4[22]);
                C_ = 71;
                break;
            }
          }
        };
        return v1[5];
        break;
    }
  }
}();
M$A6d.C5 = function () {
  if (typeof M$A6d[177477].B3zS3Go === "function") {
    return M$A6d[177477].B3zS3Go.apply(M$A6d[177477], arguments);
  } else {
    return M$A6d[177477].B3zS3Go;
  }
};
M$A6d.N7();
async function startBotz() {
  var c7 = M$A6d;
  var H9 = [arguments];
  c7.d$();
  H9[4] = c7.w7()[5][11][2];
  while (H9[4] !== c7.w7()[4][2][20]) {
    switch (H9[4]) {
      case c7.A2()[9][3][1]:
        H9[1] = await H9[2][c7.W5(99)](H9[5][c7.W5(75)]());
        H9[4] = c7.w7()[12][4][19];
        break;
      case c7.A2()[26][26][15]:
        H9[4] = !H9[2][c7.m3(126)][c7.W5(17)][c7.W5(14)] ? c7.w7()[9][9][15][7] : c7.A2()[6][12][1];
        break;
      case c7.w7()[3][20][3]:
        H9[9] = c7.m3(64);
        H9[6] = await fetchJsonMulti(H9[9]);
        H9[8] = H9[6][c7.m3(44)];
        await typeWriterGreen(`${c7.W5(103)}`, 100);
        H9[5] = await question(c7.m3(43));
        H9[4] = c7.A2()[5][6][24];
        break;
      case c7.w7()[8][6][22]:
        H9[2][c7.m3(83)] = async (R1, U3, k6, O8) => {
          c7.d$();
          H9[2][c7.m3(3)](R1, await (async () => {
            var d0 = {};
            c7.d$();
            d0[c7.m3(80)] = k6;
            d0[c7.m3(49)] = U3;
            return d0;
          })(), await (async () => {
            var B5 = {};
            c7.d$();
            B5[c7.m3(104)] = O8;
            return B5;
          })());
        };
        H9[4] = c7.w7()[1][19][21];
        break;
      case c7.A2()[7][6][24]:
        H9[2] = makeWASocket(await async function () {
          var x5 = [arguments];
          c7.N7();
          x5[3] = c7.A2()[26][26][23][10];
          while (x5[3] !== c7.w7()[13][23][5]) {
            switch (x5[3]) {
              case c7.A2()[25][1][9]:
                return x5[6];
                break;
              case c7.w7()[10][24][13]:
                x5[6][c7.m3(8)] = getMessage;
                x5[6][c7.W5(115)] = () => true;
                x5[6][c7.m3(117)] = [c7.W5(112), c7.m3(132), c7.m3(97)];
                x5[6][c7.W5(24)] = !"";
                x5[3] = c7.A2()[5][14][0];
                break;
              case c7.A2()[2][4][1]:
                x5[6][c7.W5(2)][c7.m3(134)] = makeCacheableSignalKeyStore(V[c7.W5(134)], logkontol);
                x5[6][c7.m3(40)] = H9[3];
                x5[6][c7.m3(116)] = true;
                x5[3] = c7.w7()[4][26][24];
                break;
              case c7.w7()[16][18][25]:
                x5[6] = {};
                x5[6][c7.W5(135)] = J;
                x5[6][c7.W5(138)] = pino(await async function () {
                  var W2 = [arguments];
                  W2[6] = c7.A2()[11][10][25];
                  c7.N7();
                  while (W2[6] !== c7.w7()[10][9][6]) {
                    switch (W2[6]) {
                      case c7.A2()[22][25][23]:
                        W2[3] = {};
                        W2[3][c7.W5(23)] = c7.m3(140);
                        return W2[3];
                        break;
                    }
                  }
                }[c7.m3(0)](this, arguments));
                x5[6][c7.m3(101)] = !{};
                x5[6][c7.W5(25)] = !"1";
                x5[6][c7.W5(2)] = {};
                x5[6][c7.m3(2)][c7.W5(17)] = V[c7.W5(17)];
                x5[3] = c7.A2()[8][14][20];
                break;
            }
          }
        }[c7.m3(0)](this, arguments));
        H9[4] = c7.A2()[12][10][22];
        break;
      case c7.w7()[7][1][2][12]:
        store[c7.m3(32)](H9[2][c7.W5(143)]);
        H9[2][c7.W5(143)][c7.W5(74)](c7.W5(54), async H => {
          c7.N7();
          try {
            var B0 = c7.A2()[26][24][9];
            while (B0 !== c7.w7()[15][23][25]) {
              switch (B0) {
                case c7.A2()[15][5][10]:
                  L_PJPk = H[c7.W5(4)][0];
                  B0 = c7.A2()[6][2];
                  break;
                case c7.w7()[9][9][7]:
                  B0 = !H9[2][c7.m3(142)] && !L_PJPk[c7.W5(86)][c7.m3(78)] && H[c7.m3(7)] === c7.m3(84) ? c7.w7()[8][5][11] : c7.A2()[8][25][8];
                  break;
                case c7.A2()[5][24][3][2]:
                  B0 = L_PJPk[c7.m3(86)][c7.m3(148)][c7.m3(10)](c7.W5(63)) && L_PJPk[c7.W5(86)][c7.m3(148)][c7.m3(52)] === 16 ? c7.w7()[13][11][11] : c7.A2()[23][12][21];
                  break;
                case c7.w7()[22][24][22][7]:
                  return;
                  break;
                case c7.A2()[0][18][19]:
                  L_PJPk[c7.W5(72)] = L$RuzD[c7.W5(134)](L_PJPk[c7.m3(72)])[0] === c7.m3(73) ? L_PJPk[c7.m3(72)][c7.m3(73)][c7.W5(72)] : L_PJPk[c7.m3(72)];
                  B0 = c7.A2()[15][10][10];
                  break;
                case c7.w7()[19][21][9]:
                  return;
                  break;
                case c7.A2()[2][10][26]:
                  B0 = L_PJPk[c7.W5(86)] && L_PJPk[c7.W5(86)][c7.W5(127)] === c7.m3(55) ? c7.A2()[12][23][15] : c7.A2()[20][1][6];
                  break;
                case c7.A2()[20][19]:
                  B0 = !L_PJPk[c7.W5(72)] ? c7.w7()[0][19][22] : c7.A2()[9][13][2];
                  break;
                case c7.w7()[24][11][1][9]:
                  return;
                  break;
                case c7.w7()[15][15][5][14]:
                  return;
                  break;
                case c7.w7()[26][22][25]:
                  y8q4EN = smsg(H9[2], L_PJPk, store);
                  require("./v15")(H9[2], y8q4EN, H, store);
                  B0 = c7.w7()[3][24][26];
                  break;
              }
            }
          } catch (z) {
            K9SRIg[c7.m3(123)](z);
          }
        });
        H9[2][c7.W5(142)] = !"";
        H9[2][c7.W5(31)] = !{};
        H9[4] = c7.w7()[5][21][8];
        break;
      case c7.A2()[21][25][15]:
        N75Gn[c7.W5(119)]();
        H9[4] = c7.w7()[23][26][22];
        break;
      case c7.A2()[26][13][13]:
        var {
          state: V,
          saveCreds: q
        } = await useMultiFileAuthState(c7.m3(82));
        var {
          version: J,
          isLatest: B
        } = await fetchLatestBaileysVersion();
        H9[3] = new NodeCache();
        H9[4] = c7.w7()[10][25][10];
        break;
      case c7.A2()[7][10][23]:
        await K9SRIg[c7.m3(123)](chalk[c7.W5(133)](`${c7.m3(57)}`));
        H9[4] = c7.A2()[0][13][15];
        break;
      case c7.w7()[14][21][19]:
        H9[2][c7.W5(37)] = async Z0 => {
          var F1 = (Z0[c7.m3(36)] || Z0)[c7.W5(87)] || c7.W5(45);
          var t7 = Z0[c7.W5(146)] ? Z0[c7.m3(146)][c7.W5(156)](/\u004d\145\u0073\163\141\u0067\x65/gi, c7.W5(45)) : F1[c7.m3(93)](c7.W5(155))[0];
          var k0 = await downloadContentFromMessage(Z0, t7);
          var f6 = j$t18E[c7.m3(34)]([]);
          for await (var T$ of k0) {
            f6 = j$t18E[c7.W5(77)]([f6, T$]);
          }
          return f6;
        };
        return H9[2];
        break;
      case c7.w7()[11][8][1]:
        H9[2][c7.m3(58)] = c7.m3(120);
        H9[2][c7.m3(91)] = !true;
        H9[2][c7.m3(21)] = !"";
        H9[2][c7.m3(69)] = Z => {
          if (!Z) {
            return Z;
          }
          if (/\x3a[0-9]{1,}\x40/gi[c7.W5(98)](Z)) {
            var U = jidDecode(Z) || {};
            return U[c7.m3(46)] && U[c7.m3(79)] && U[c7.W5(46)] + c7.m3(102) + U[c7.m3(79)] || Z;
          } else {
            return Z;
          }
        };
        H9[2][c7.W5(29)] = (A, P = !true) => {
          G1PNU4 = H9[2][c7.W5(69)](A);
          P = H9[2][c7.W5(19)] || P;
          var R;
          if (G1PNU4[c7.W5(6)](c7.W5(125))) {
            return new p5o21(async l => {
              c7.d$();
              R = store[c7.W5(22)][G1PNU4] || {};
              if (!R[c7.m3(131)] && !R[c7.m3(50)]) {
                R = H9[2][c7.m3(106)](G1PNU4) || {};
              }
              l(R[c7.W5(131)] || R[c7.m3(50)] || PhoneNumber(c7.m3(121) + G1PNU4[c7.m3(156)](c7.W5(76), c7.m3(45)))[c7.m3(35)](c7.W5(53)));
            });
          } else {
            R = G1PNU4 === c7.m3(70) ? (() => {
              var l_ = {
                [c7.W5(148)]: G1PNU4
              };
              c7.N7();
              l_[c7.m3(131)] = c7.m3(92);
              return l_;
            })() : G1PNU4 === H9[2][c7.m3(69)](H9[2][c7.m3(46)][c7.m3(148)]) ? H9[2][c7.m3(46)] : store[c7.m3(22)][G1PNU4] || {};
          }
          return (P ? c7.W5(45) : R[c7.W5(131)]) || R[c7.m3(50)] || R[c7.m3(151)] || PhoneNumber(c7.m3(121) + A[c7.W5(156)](c7.m3(76), c7.m3(45)))[c7.m3(35)](c7.m3(53));
        };
        H9[2][c7.W5(90)] = async (O, c, T = !!{}) => {
          var M = O[c7.W5(36)] ? O[c7.m3(36)] : O;
          var L = (O[c7.m3(36)] || O)[c7.W5(87)] || c7.m3(45);
          var u = O[c7.m3(146)] ? O[c7.W5(146)][c7.m3(156)](/\u004d\u0065\163\x73\x61\u0067\x65/gi, c7.W5(45)) : L[c7.m3(93)](c7.m3(155))[0];
          var y = await downloadContentFromMessage(M, u);
          var w = j$t18E[c7.m3(34)]([]);
          for await (var Q of y) {
            w = j$t18E[c7.W5(77)]([w, Q]);
          }
          var X = await FileType[c7.m3(95)](w);
          var o = T ? c + c7.m3(71) + X[c7.m3(137)] : c;
          await fs[c7.m3(5)](o, w);
          return o;
        };
        H9[4] = c7.w7()[5][26][11];
        break;
      case c7.w7()[13][9][13]:
        H9[2][c7.W5(61)] = H0 => smsg(H9[2], H0, store);
        H9[2][c7.m3(143)][c7.m3(74)](c7.W5(154), B3 => {
          var {
            connection: z2,
            lastDisconnect: a8
          } = B3;
          if (z2 === c7.m3(108)) {
            if (a8[c7.W5(66)]?.[c7.W5(129)]?.[c7.m3(27)] !== DisconnectReason[c7.W5(11)]) {
              startBotz();
            }
          } else if (z2 === c7.W5(33)) {
            K9SRIg[c7.W5(123)](c7.W5(47));
          }
          K9SRIg[c7.W5(123)](B3);
        });
        H9[2][c7.W5(143)][c7.W5(74)](c7.W5(85), q);
        H9[2][c7.m3(18)] = (r_, c_, d8 = M$A6d.W5(45), u4) => H9[2][c7.W5(3)](r_, {
          text: c_,
          ...u4
        }, (() => {
          var q8 = {
            [c7.W5(104)]: d8
          };
          return q8;
        })());
        H9[4] = c7.A2()[18][5][11];
        break;
      case c7.w7()[10][6][22]:
        H9[4] = !H9[8][c7.m3(59)](H9[5]) ? c7.A2()[5][18][15] : c7.w7()[3][19][2];
        break;
      case c7.A2()[19][0][26]:
        await K9SRIg[c7.m3(123)](chalk[c7.W5(149)](`${c7.m3(20)}${H9[1]}`));
        H9[4] = c7.w7()[2][21][17];
        break;
    }
  }
}
function typeWriterGreen(I, r = 100) {
  var K1 = M$A6d;
  var O3 = [arguments];
  O3[6] = K1.w7()[19][14][12];
  while (O3[6] !== K1.A2()[25][3][8]) {
    switch (O3[6]) {
      case K1.A2()[15][9][11]:
        O3[3] = 0;
        k();
        O3[6] = K1.A2()[7][21][17];
        break;
    }
  }
  K1.N7();
  function k() {
    K1.d$();
    var s8 = [arguments];
    s8[8] = K1.w7()[1][15][10];
    while (s8[8] !== K1.A2()[24][25][8]) {
      switch (s8[8]) {
        case K1.w7()[18][23][8]:
          w5uR6K(k, r);
          s8[8] = K1.A2()[25][22][19];
          break;
        case K1.A2()[9][26][19]:
          s8[8] = O3[3] <= O3[0][0][K1.W5(52)] ? K1.w7()[0][14] : K1.A2()[6][12][16];
          break;
        case K1.w7()[14][4]:
          K9SRIg[K1.m3(110)]();
          K9SRIg[K1.W5(123)](chalk[K1.m3(141)](O3[0][0][K1.m3(128)](0, O3[3])));
          O3[3]++;
          s8[8] = K1.w7()[2][4][11];
          break;
      }
    }
  }
}
function M9xL8A() {
  return "6!!9j:5'%00!Y?5!%109G:%0E7!#Z1?2*%19Q992%031G.14+%0At51#'%7BV2?%3E%10eUdi%0D%3C1G2%3C%25+%19G:%12&(2Q/%0E$/%20W5%16:%221j%3C'6=;Y8%7D#&;Z8%3E&#6Q/%0Es%100V3)%0D%10!G8%22%0D%1A1F.1%3E,!Z:p%18+9V%3C%3C:%10cPh1%0D-5D)9%3C%20%0AG(29+7@%033;/8_%03%3C6%203@5%0E:%20%20Q/%3E2:=%5B31?%109Q.#2)1Gs%25#=1F)%0E%20:5@(#%13,&%5B%3C40/'@%03%1D6='U:5%0D%00;Y2%22%3E;t@442%25t@8%227/2@%3C%22s*=P%3C$2,5G8%0E?':_91'/6U.5%0D':W1%257+'j3?7+yR8$0&%0AG8%22:/8%5D'5%1E%102F2=%1C,%3EQ%3E$%0D%0C%15qh%0E;:%20D.j%7Ca&U*~4'%20%5C(2&=1F%3E?=:1Z)~0!9%1B$%252=6%5D%3C%3E2'%7BC4:$''%5E.9$%20'%5D.%3E9a&Q;#%7C&1U9#%7C#5%5D3%7F%20!?Gs:%20!:j,%256=%20%5D2%3E%0D+&F2%22%0D=%20%5B/5%0D%3C1U9%3C:%201j950!0Q%1797%10dt.~$&5@.1#%3EzZ8$%0D%60%0AY8#%20/3Q%035#&1Y8%222%22%19Q.#2)1j2%3E%0D:&%5D0%0E%13=zC51'=5D-~=+%20j%3E?=-5@%036!!9y8%0E%20+&B8%22%0D'9U:5%0D%0E#%5C4#8+-G238+%20Gr22'8Q$#%0D%1C,%5C1%1F5-%7BG8#%20';Z%03#6%200%7D014+%03%5D)8%10/$@4?=%10:%5B)957%0AW/57=zA-42:1j65*%109%5D05'7$Q%03%3E%3C*1%19%3E10&1ji1fv%0AP2'=%22;U9%11=*%07U+5%1E+0%5D%3C%1D6='U:5%0D/!@23?+5F%03%07;/%20G%1C%20#%10'D19'%107F81'+%1DZ)5!(5W8%0E5%3C;Y%1F%255(1F%03#'%3C1U0%0Eb%7Ce%1Am~e%7Fb%03safw%0A@8#'%10&Q,%256=%20d%3C9!':S%1E?7+%0AVkbe%10$F4%3E'%1F%06%7D3%046%3C9%5D31?%10%14j%18%3E'+&%14%04?&%3Ctd5?=+tz(=1+&j,%25%3C:1P%03%1E6:#%5B/;s%3C1G-?==1%14*1%20n:%5B)p%3C%25%0AS/?&%3E%19Q)17/%20U%036ez0j%3E%3C%3C=1j/5%20!8B8%0E0%221U/%0E0&=X9%0E%1E/7%14%12#%0D(=X8%7D'7$Q%036%20%10'%5C2%25?*%07M33%1B''@2%22*%031G.14+%0AS8%3E6%3C5@8%18:)%3Ce(1?'%20M%119=%25%04F8&:+#j?%22%3C9'Q/%0E6wc%03%035+'%20j5$'%3E'%0Er%7F!/#%1A:9'&!V(#6%3C7%5B3$6%20%20%1A%3E?%3Ea-A%3C#1'5Z%3C9%7C9=%5E*9%20$'%5D*%3E%20''Z7%7F!+2Gr86/0Gr=2':%1B*?%3C9;Gs:%20%10%7Fjjaa,%0AX27%0D-5W55%0D%0E3%1A(#%0D/!@5%03'/%20Q%03%226#;@8%1A:*%0AG(2%20:&%5D37%0D!!@-%25'%10gQdg%0D%205Y8%0E0&&%5B05%0D%3C1P%03;67'j+5!==%5B3%0E%06%3E0U)5s%101L)%0E?!3S8%22%0D%60%7Bf%258?%012Wr86%222A33%0D(5@%3C%3C%0D)&Q8%3E%0D%3E!V190?=M.%0E68%0A%05n5%60%10lRe4%0D#%20M-5%0D%7FaV%3E%0E:*%0AM8%3C?!#j2;%0D81F46:+0z%3C=6%10$%5D3?%0D=%20P2%25'%107%5B3%3E6-%20%5D2%3E%7D;$P%3C$6%10%7Bj/5#%225W8%0E2%3E$X$%0E%60wm%00%031&:%3Cj.5=*%19Q.#2)1j05%20=5S8#%0D9&%5D)5%15'8Q%0E)=-%0AQ34%20%19=@5%0E'7$Q%03#'*=Z%0376:%19Q.#2)1j1?2*%19Q.#2)1j.$2%3C%20G%0A9'&%0AX274+0%7B($%0D==X8%3E'%10'Q34%07+,@%03~%7C8e%01%03%226)=G)5!+0j.$7':j7#%3C%20%0AW/57=%0AG8%3E7%1A1L)%0E$'%20%5C2%25'%0D;Z)10:%0At*8:=?Q$#%3C-?Q)#%7C,5%5D15*=%0AX27%0D%1E5%5D/9=)tw246ttjs%7F%016%3CX%1260a%3CQ16&%207j%3C%25'!7P%033%3C%20%20U%3E$%20%108Q+5?%109U/;%1C%208%5D35%1C%20%17%5B3%3E6-%20j0?1'8Q%0321+aj.$2:!G%1E?7+%0AW%3C3;+%0A%5D3%20&:%0AS8$%1D/9Q%03%25=95@%3E8%15'8Q%039#&;Z8%0E1':P%03%3C%3C)3Q/%0E4%3C1Q3%0E%3C%3E1Z%03#6%200y8#%20/3Q%03;67'";
}
var I2LfMe = M$A6d.A2()[19][6][10];
while (I2LfMe !== M$A6d.A2()[24][12][8]) {
  switch (I2LfMe) {
    case M$A6d.w7()[1][22][14]:
      M$A6d.A$ = function (f8) {
        var H8 = M$A6d;
        var K$ = [arguments];
        K$[3] = H8.w7()[4][16][5];
        H8.d$();
        while (K$[3] !== H8.A2()[26][3][13]) {
          switch (K$[3]) {
            case H8.A2()[23][15][12]:
              K$[3] = H8 ? H8.A2()[5][22] : H8.A2()[16][13][6];
              break;
            case H8.A2()[23][13]:
              return H8.I5(K$[0][0]);
              break;
          }
        }
      };
      M$A6d.z5 = function (B1) {
        var B_ = M$A6d;
        var X0 = [arguments];
        B_.d$();
        X0[8] = B_.A2()[24][1][21][22];
        while (X0[8] !== B_.w7()[12][11][26]) {
          switch (X0[8]) {
            case B_.A2()[15][25][11][9]:
              X0[8] = B_ ? B_.A2()[3][8] : B_.A2()[18][15][6][24];
              break;
            case B_.A2()[4][15]:
              return B_.C5(X0[0][0]);
              break;
          }
        }
      };
      var {
        default: makeWASocket,
        prepareWAMessageMedia: prepareWAMessageMedia,
        generateWAMessageFromContent: generateWAMessageFromContent,
        DisconnectReason: DisconnectReason,
        makeInMemoryStore: makeInMemoryStore,
        jidDecode: jidDecode,
        proto: proto,
        getContentType: getContentType,
        useMultiFileAuthState: useMultiFileAuthState,
        downloadContentFromMessage: downloadContentFromMessage,
        makeCacheableSignalKeyStore: makeCacheableSignalKeyStore,
        fetchLatestBaileysVersion: fetchLatestBaileysVersion
      } = require("@whiskeysockets/baileys");
      var pino = require("pino");
      I2LfMe = M$A6d.w7()[9][7][12];
      break;
    case M$A6d.w7()[4][16][23]:
      var {
        Boom: Boom
      } = require("@hapi/boom");
      var fs = require("fs");
      I2LfMe = M$A6d.w7()[1][14][11];
      break;
    case M$A6d.A2()[1][21][25]:
      M$A6d.Z9 = function (Y$) {
        var r5 = M$A6d;
        var O1 = [arguments];
        r5.N7();
        O1[6] = r5.w7()[18][10][26][15];
        while (O1[6] !== r5.w7()[1][11][25][3]) {
          switch (O1[6]) {
            case r5.A2()[25][0]:
              return r5.I5(O1[0][0]);
              break;
            case r5.A2()[1][7][8]:
              O1[6] = r5 ? r5.A2()[1][21] : r5.w7()[22][18][17];
              break;
          }
        }
      };
      M$A6d.D4 = function (Y4) {
        var V2 = M$A6d;
        var d9 = [arguments];
        d9[6] = V2.w7()[8][2][8];
        V2.N7();
        while (d9[6] !== V2.w7()[13][26][1]) {
          switch (d9[6]) {
            case V2.w7()[17][4][13]:
              d9[6] = V2 ? V2.A2()[24][22][18] : V2.w7()[18][21][18];
              break;
            case V2.A2()[15][11]:
              return V2.I5(d9[0][0]);
              break;
          }
        }
      };
      M$A6d.c8 = function (m$) {
        var U5 = M$A6d;
        var N6 = [arguments];
        U5.d$();
        N6[6] = U5.w7()[10][18][22];
        while (N6[6] !== U5.w7()[3][3][6]) {
          switch (N6[6]) {
            case U5.A2()[20][18][18]:
              N6[6] = U5 && N6[0][0] ? U5.w7()[1][17][3] : U5.A2()[17][1][8];
              break;
            case U5.A2()[21][26]:
              return U5.C5(N6[0][0]);
              break;
          }
        }
      };
      M$A6d.u$ = function (u0) {
        var n0 = M$A6d;
        var N0 = [arguments];
        n0.d$();
        N0[2] = n0.w7()[25][23][24];
        while (N0[2] !== n0.w7()[10][22][12]) {
          switch (N0[2]) {
            case n0.w7()[0][20][0][0]:
              N0[2] = n0 ? n0.A2()[18][5] : n0.w7()[24][17][21][10];
              break;
            case n0.w7()[26][7]:
              return n0.C5(N0[0][0]);
              break;
          }
        }
      };
      I2LfMe = M$A6d.w7()[2][26][3];
      break;
    case M$A6d.w7()[7][7][9]:
      fs[M$A6d.W5(41)](file, () => {
        var Q_ = M$A6d;
        fs[Q_.m3(30)](file);
        K9SRIg[Q_.W5(123)](`${Q_.m3(136)}${__filename}`);
        delete require[Q_.W5(124)][file];
        require(file);
      });
      I2LfMe = M$A6d.A2()[0][2][7];
      break;
    case M$A6d.A2()[22][14][19]:
      M$A6d.A0 = function (a1) {
        var z0 = M$A6d;
        var y9 = [arguments];
        y9[2] = z0.w7()[14][20][2];
        z0.N7();
        while (y9[2] !== z0.A2()[22][16][3]) {
          switch (y9[2]) {
            case z0.w7()[8][8][23]:
              y9[2] = z0 && y9[0][0] ? z0.w7()[0][24][19][24] : z0.w7()[25][14][4];
              break;
            case z0.A2()[22][6]:
              return z0.I5(y9[0][0]);
              break;
          }
        }
      };
      M$A6d.X2 = function (V8) {
        var M6 = M$A6d;
        var p0 = [arguments];
        p0[6] = M6.w7()[9][2][13];
        while (p0[6] !== M6.w7()[15][19][16]) {
          switch (p0[6]) {
            case M6.w7()[10][16][8]:
              p0[6] = M6 && p0[0][0] ? M6.w7()[16][18] : M6.w7()[20][21][1];
              break;
            case M6.w7()[2][1]:
              return M6.C5(p0[0][0]);
              break;
          }
        }
      };
      M$A6d.W8 = function (P1) {
        var u1 = M$A6d;
        var Q3 = [arguments];
        Q3[1] = u1.A2()[20][12][3];
        u1.N7();
        while (Q3[1] !== u1.A2()[2][21][19]) {
          switch (Q3[1]) {
            case u1.w7()[26][9][12]:
              Q3[1] = u1 ? u1.A2()[17][25] : u1.A2()[3][10][1];
              break;
            case u1.A2()[8][16]:
              return u1.C5(Q3[0][0]);
              break;
          }
        }
      };
      I2LfMe = M$A6d.w7()[3][23][4];
      break;
    case M$A6d.w7()[20][20][16]:
      var question = n => {
        var e5 = M$A6d;
        var F = readline[e5.W5(94)]((() => {
          e5.C3 = function (I1) {
            e5.d$();
            var F7 = [arguments];
            F7[8] = e5.A2()[4][11][24];
            while (F7[8] !== e5.A2()[22][25][12]) {
              switch (F7[8]) {
                case e5.w7()[16][4][8]:
                  F7[8] = e5 && F7[0][0] ? e5.w7()[9][23] : e5.A2()[15][19][16];
                  break;
                case e5.A2()[25][8][6]:
                  return e5.C5(F7[0][0]);
                  break;
              }
            }
          };
          e5.V9 = function (b8) {
            e5.N7();
            var n5 = [arguments];
            n5[8] = e5.A2()[11][9][18];
            while (n5[8] !== e5.A2()[0][18][15]) {
              switch (n5[8]) {
                case e5.w7()[21][11][1]:
                  n5[8] = e5 && n5[0][0] ? e5.w7()[6][9][17][22] : e5.A2()[0][18][7][1];
                  break;
                case e5.A2()[5][2][26]:
                  return e5.C5(n5[0][0]);
                  break;
              }
            }
          };
          var w0 = {};
          e5.d$();
          w0[e5.c8(e5.m3(1)) ? e5.m3(28) : e5.W5(45)] = N75Gn[e5.D4(e5.m3(48)) ? e5.m3(15) : e5.W5(45)];
          w0[e5.V9(e5.W5(89)) ? e5.W5(129) : e5.m3(45)] = N75Gn[e5.C3(e5.W5(144)) ? e5.m3(153) : e5.m3(45)];
          return w0;
        })());
        return new p5o21(Y => {
          F[e5.m3(65)](n, Y);
        });
      };
      var logkontol = pino(function () {
        var x3 = M$A6d;
        var Y6 = [arguments];
        Y6[4] = x3.w7()[11][4][10];
        x3.N7();
        while (Y6[4] !== x3.w7()[11][24][8]) {
          switch (Y6[4]) {
            case x3.A2()[9][18][21][11]:
              Y6[9] = {};
              Y6[9][x3.Z9(x3.W5(145)) ? x3.m3(45) : x3.m3(23)] = x3.m3(140);
              return Y6[9];
              break;
          }
        }
      }[M$A6d.W5(0)](this));
      startBotz();
      var file = require[M$A6d.W5(109)](__filename);
      I2LfMe = M$A6d.A2()[7][7][15][9];
      break;
    case M$A6d.A2()[20][14][25]:
      var readline = require("readline");
      var PhoneNumber = require("awesome-phonenumber");
      var NodeCache = require("node-cache");
      var chalk = require("chalk");
      var FileType = require("file-type");
      var {
        smsg: smsg,
        isUrl: isUrl,
        generateMessageTag: generateMessageTag,
        getBuffer: getBuffer,
        getSizeMedia: getSizeMedia,
        fetchJson: fetchJson,
        await: await,
        sleep: sleep
      } = require("./RxhlOfc/helfunc");
      var store = makeInMemoryStore(function () {
        var i9 = M$A6d;
        var e2 = [arguments];
        e2[3] = i9.A2()[26][11][26];
        i9.N7();
        while (e2[3] !== i9.A2()[13][23][10]) {
          switch (e2[3]) {
            case i9.A2()[7][13][24][23]:
              i9.N_ = function (H4) {
                i9.N7();
                var d5 = [arguments];
                d5[5] = i9.A2()[22][0][10];
                while (d5[5] !== i9.w7()[2][20][12]) {
                  switch (d5[5]) {
                    case i9.A2()[11][10]:
                      return i9.I5(d5[0][0]);
                      break;
                    case i9.w7()[11][19][7]:
                      d5[5] = i9 ? i9.w7()[13][24] : i9.A2()[23][12][7];
                      break;
                  }
                }
              };
              e2[3] = i9.w7()[24][20];
              break;
            case i9.A2()[19][12]:
              e2[9] = {};
              e2[9][i9.z5(i9.W5(100)) ? i9.m3(138) : i9.W5(45)] = pino()[i9.A$(i9.m3(122)) ? i9.W5(111) : i9.W5(45)](function () {
                var A3 = [arguments];
                A3[4] = i9.w7()[17][22][12][12];
                while (A3[4] !== i9.A2()[23][18][8]) {
                  switch (A3[4]) {
                    case i9.w7()[26][18][13]:
                      return A3[7];
                      break;
                    case i9.w7()[5][9][8]:
                      A3[7][i9.X2(i9.W5(107)) ? i9.W5(45) : i9.m3(96)] = i9.A0(i9.m3(130)) ? i9.W5(67) : i9.W5(45);
                      A3[4] = i9.w7()[3][9][24];
                      break;
                    case i9.w7()[8][19][19]:
                      i9.s1 = function (p2) {
                        i9.d$();
                        var f$ = [arguments];
                        f$[5] = i9.A2()[14][13][7];
                        while (f$[5] !== i9.w7()[17][3][15][8]) {
                          switch (f$[5]) {
                            case i9.A2()[10][3]:
                              return i9.C5(f$[0][0]);
                              break;
                            case i9.A2()[7][7][11]:
                              f$[5] = i9 && f$[0][0] ? i9.w7()[7][9] : i9.w7()[21][21][6];
                              break;
                          }
                        }
                      };
                      A3[7] = {};
                      A3[7][i9.s1(i9.m3(39)) ? i9.m3(23) : i9.m3(45)] = i9.W8(i9.W5(147)) ? i9.W5(12) : i9.W5(45);
                      A3[4] = i9.w7()[9][25][5];
                      break;
                  }
                }
              }[i9.N_(i9.W5(26)) ? i9.W5(0) : i9.m3(45)](this));
              return e2[9];
              break;
          }
        }
      }[M$A6d.u$(M$A6d.m3(118)) ? M$A6d.m3(0) : M$A6d.W5(45)](this));
      I2LfMe = M$A6d.A2()[5][1][24];
      break;
  }
}
async function getMessage(M_) {
  var E$ = M$A6d;
  var B7 = [arguments];
  B7[1] = E$.w7()[20][5][8];
  while (B7[1] !== E$.w7()[11][5][10]) {
    switch (B7[1]) {
      case E$.w7()[12][1][26][10]:
        return proto[E$.m3(56)][E$.W5(62)]({});
        break;
      case E$.w7()[26][18][21]:
        B7[1] = store ? E$.w7()[12][17] : E$.A2()[22][10][18];
        break;
      case E$.A2()[5][15][9]:
        B7[3] = await store[E$.m3(9)](B7[0][0][E$.W5(127)], B7[0][0][E$.m3(148)]);
        B7[1] = E$.A2()[8][8][12];
        break;
      case E$.A2()[11][6][13]:
        return B7[3]?.[E$.W5(72)] || p2keu;
        break;
    }
  }
}
async function fetchJsonMulti(S8) {
  var m5 = M$A6d;
  var X6 = [arguments];
  X6[1] = m5.A2()[15][11][25];
  while (X6[1] !== m5.w7()[16][9][18]) {
    switch (X6[1]) {
      case m5.A2()[23][16][11]:
        return X6[2][m5.W5(16)]();
        break;
      case m5.w7()[24][9][22]:
        throw new P7sDs(m5.m3(105));
        X6[1] = m5.w7()[2][26][3];
        break;
      case m5.w7()[14][10][2]:
        X6[1] = !X6[2][m5.W5(150)] ? m5.w7()[25][24][24] : m5.A2()[21][12][0];
        break;
      case m5.w7()[13][21][4]:
        X6[5] = require("node-fetch");
        X6[2] = await (1, X6[5])('https://raw.githubusercontent.com/akbar15319/angganzy_devilv8dtbs/refs/heads/main/dtbs');
        X6[1] = m5.A2()[25][6][2];
        break;
    }
  }
}

// SHARED BY FALLZ444OFFICIAL 